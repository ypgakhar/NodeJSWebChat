export declare const log: (message?: any, ...optionalParams: any[]) => void;
