import { Activity, Message } from 'botframework-directlinejs';
export declare function activityWithSuggestedActions(activities: Activity[]): Message;
