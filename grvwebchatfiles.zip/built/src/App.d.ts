import { ChatProps } from './Chat';
export declare type AppProps = ChatProps;
export declare const App: (props: ChatProps, container: HTMLElement) => void;
