import { Speech } from './SpeechModule';
export declare class SpeechOptions {
    speechRecognizer: Speech.ISpeechRecognizer;
    speechSynthesizer: Speech.ISpeechSynthesizer;
}
