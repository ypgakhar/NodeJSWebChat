"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SpeechRecognition_1 = require("./SpeechRecognition");
exports.SpeechRecognizer = SpeechRecognition_1.SpeechRecognizer;
var SpeechSynthesis_1 = require("./SpeechSynthesis");
exports.SpeechSynthesizer = SpeechSynthesis_1.SpeechSynthesizer;
exports.SynthesisGender = SpeechSynthesis_1.SynthesisGender;
//# sourceMappingURL=lib.js.map