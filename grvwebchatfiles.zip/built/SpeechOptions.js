"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SpeechOptions = (function () {
    function SpeechOptions() {
    }
    return SpeechOptions;
}());
exports.SpeechOptions = SpeechOptions;
//# sourceMappingURL=SpeechOptions.js.map