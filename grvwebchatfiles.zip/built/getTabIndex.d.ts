export declare function getTabIndex(element: HTMLElement): number;
