/// <reference types="react" />
import * as React from 'react';
export interface ShellFunctions {
    focus: (appendKey?: string) => void;
}
export declare const Shell: React.ComponentClass<any>;
