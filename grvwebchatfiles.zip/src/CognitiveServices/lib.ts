export { SpeechRecognizer } from './SpeechRecognition';
export { SpeechSynthesizer, SynthesisGender } from './SpeechSynthesis';
