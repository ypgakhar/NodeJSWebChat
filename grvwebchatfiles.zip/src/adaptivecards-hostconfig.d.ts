declare module "*/adaptivecards-hostconfig.json" {
    import { HostConfig } from "adaptivecards";
    const _: HostConfig;
    export = _;
}
